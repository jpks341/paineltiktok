<?php
/**
 * Created by PhpStorm.
 * User: m0pfin
 * Date: 11.07.2020
 * Time: 19:20
 */

return [
    'host' => 'localhost',
    'db_name' => 'painel_custos', // Имя базы данных
    'user' => 'josias', // Юзер базы данных
    'password' => 'josias456', // Пароль базы данных
    'charset' => 'utf8'
];
